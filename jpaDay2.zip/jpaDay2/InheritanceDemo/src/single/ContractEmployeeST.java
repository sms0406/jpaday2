package single;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("ce")
public class ContractEmployeeST extends EmployeeST{
	
	private Integer wages;

	public Integer getWages() {
		return wages;
	}

	public void setWages(Integer wages) {
		this.wages = wages;
	}
	

}
