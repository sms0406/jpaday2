package single;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SingleTableDao {
	
	public void addRecord() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("day2");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			
			PermanentEmployeeST pe = new PermanentEmployeeST();
			pe.setEmpId(1002);
			pe.setEmpName("sam");
			pe.setSalary(35000);
			em.persist(pe);
			/*ContractEmployeeST ce = new ContractEmployeeST();
			ce.setEmpId(2001);
			ce.setEmpName("john");
			ce.setWages(200);
			em.persist(ce);*/
			
			/*EmployeeST emp = new EmployeeST();
			emp.setEmpId(3001);
			emp.setEmpName("ram");
			em.persist(emp);*/
			em.getTransaction().commit();
			
	
			
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}




	}

}
