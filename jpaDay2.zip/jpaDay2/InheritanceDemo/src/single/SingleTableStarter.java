package single;

public class SingleTableStarter {
	
	public static void main(String[] args) {
		new SingleTableDao().addRecord();
		System.out.println("done");
	}

}
