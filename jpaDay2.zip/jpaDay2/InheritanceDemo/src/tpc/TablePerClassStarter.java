package tpc;

public class TablePerClassStarter {

	public static void main(String[] args) {
		new TablePerClassDao().addRecord();
		System.out.println("done");
	}
	
	
}
