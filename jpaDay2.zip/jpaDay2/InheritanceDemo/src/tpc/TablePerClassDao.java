package tpc;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import single.PermanentEmployeeST;

public class TablePerClassDao {
	
	public void addRecord() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("day2");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			
			PermanentEmployeeTPC pe =  new PermanentEmployeeTPC();
			pe.setEmpId(1001);
			pe.setEmpName("jack");
			pe.setSalary(34000);
			em.persist(pe);
			em.getTransaction().commit();
			
			/*PermanentEmployeeTPC pj=em.find(PermanentEmployeeTPC.class, 1001);
			System.out.println(pj.getEmpName());
			System.out.println(pj.getSalary());
	*/
			
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}

	}


}
