package tpc;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="pemployeetpc")
public class PermanentEmployeeTPC extends EmployeeTPC{
	private Integer salary;

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
	

}
