package tpc;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="cemployeetpc")
public class ContractEmployeeTPC extends EmployeeTPC{
	private Integer wages;

	public Integer getWages() {
		return wages;
	}

	public void setWages(Integer wages) {
		this.wages = wages;
	}
	

}
