package joined;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="cemployeej")
public class ContractEmployeeJ extends EmployeeJ{
	private Integer wages;

	public Integer getWages() {
		return wages;
	}

	public void setWages(Integer wages) {
		this.wages = wages;
	}
	

}
