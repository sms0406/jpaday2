package joined;

public class JoinedStarter {

	public static void main(String[] args) {
		new JoinedDao().addRecord();
		System.out.println("done");
	}
	
	
}
