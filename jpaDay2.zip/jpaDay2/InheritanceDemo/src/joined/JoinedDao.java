package joined;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import single.PermanentEmployeeST;

public class JoinedDao {
	
	public void addRecord() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("day2");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			
			PermanentEmployeeJ pe =  new PermanentEmployeeJ();
			pe.setEmpId(1001);
			pe.setEmpName("jack");
			pe.setSalary(34000);
			//em.persist(pe);
			em.getTransaction().commit();
			
			PermanentEmployeeJ pj=em.find(PermanentEmployeeJ.class, 1001);
			System.out.println(pj.getEmpName());
			System.out.println(pj.getSalary());
	
			
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}

	}


}
