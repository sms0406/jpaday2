package onetoone;

public class OneToOneStarter {
	public static void main(String[] args) {
		
		new OneToOneDao().addRecord();
		System.out.println("ends");
	}

}
