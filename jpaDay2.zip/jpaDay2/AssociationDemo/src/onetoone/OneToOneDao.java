package onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class OneToOneDao {
	
	public void addRecord() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("day2");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			
			/*ParkingOTO p = new ParkingOTO();
			p.setParkingId(1);
			p.setBuildingName("b1");
			em.persist(p);*/
			
			/*ParkingOTO p = new ParkingOTO();
			p.setParkingId(3);
			p.setBuildingName("b3");*/
			/*ParkingOTO p = em.find(ParkingOTO.class,3);
			
			EmployeeOTO e = new EmployeeOTO();
			e.setEmpId(1003);
			e.setEmpName("john");
			e.setParking(p);
			em.persist(e);*/
			//ParkingOTO p = em.find(ParkingOTO.class,1);
			/*EmployeeOTO emp=em.find(EmployeeOTO.class, 1003);
			System.out.println(emp.getEmpName());
			System.out.println(emp.getParking().getBuildingName());*/
			ParkingOTO p=em.find(ParkingOTO.class, 3);
			System.out.println(p.getParkingId() + " "+p.getBuildingName()+" "+p.getEmployee().getEmpName());
			
	//emp.setParking(null);
		//	em.remove(emp);
			//emp.setParking(p);
			
			em.getTransaction().commit();
			

		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}
	}

}
