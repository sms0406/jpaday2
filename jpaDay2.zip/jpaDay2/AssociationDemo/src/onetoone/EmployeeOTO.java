package onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="emp_oto")
public class EmployeeOTO {
	@Id
	private Integer empId;
	@Column(name="name")
	private String empName;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pid", unique=true)
	private ParkingOTO parking;
	
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public ParkingOTO getParking() {
		return parking;
	}
	public void setParking(ParkingOTO parking) {
		this.parking = parking;
	}
	

}
