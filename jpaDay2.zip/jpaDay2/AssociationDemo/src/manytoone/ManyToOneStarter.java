package manytoone;

public class ManyToOneStarter {
	public static void main(String[] args) {
		
		new ManyToOneDao().addRecord();
		System.out.println("ends");
	}

}
