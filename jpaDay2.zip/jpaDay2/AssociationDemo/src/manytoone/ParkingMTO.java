package manytoone;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="park_oto")
public class ParkingMTO {
	@Id
	private Integer parkingId;
	private String buildingName;
	@OneToMany(mappedBy="parking")
	private List<EmployeeMTO> employees;
	
	public Integer getParkingId() {
		return parkingId;
	}
	public void setParkingId(Integer parkingId) {
		this.parkingId = parkingId;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public List<EmployeeMTO> getEmployees() {
		return employees;
	}
	public void setEmployees(List<EmployeeMTO> employees) {
		this.employees = employees;
	}
	
	

}
