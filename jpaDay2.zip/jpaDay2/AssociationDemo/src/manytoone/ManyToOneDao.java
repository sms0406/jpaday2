package manytoone;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class ManyToOneDao {
	
	public void addRecord() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("day2");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			
			/*ParkingMTO p = new ParkingMTO();
			p.setBuildingName("b1");
			p.setParkingId(1);
			
			EmployeeMTO e1 = new EmployeeMTO();
			e1.setEmpId(1001);
			e1.setEmpName("ram");
			e1.setParking(p);
			
			EmployeeMTO e2 = new EmployeeMTO();
			e2.setEmpId(1002);
			e2.setEmpName("raj");
			e2.setParking(p);
			
			em.persist(e1);
			em.persist(e2);*/
			
			/*EmployeeMTO e = em.find(EmployeeMTO.class, 1001);
			em.remove(e);*/
			ParkingMTO p=em.find(ParkingMTO.class, 1);
			System.out.println(p.getBuildingName());
			List<EmployeeMTO>list = p.getEmployees();
			for (EmployeeMTO emp : list) {
				System.out.println(emp.getEmpName());
			}
			em.getTransaction().commit();
			

		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}
	}

}
