package manytomany;

public class ManyToManyStarter {
	public static void main(String[] args) {
		new ManyToManyDao().doCrud();
		System.out.println("done");
	}

}
