package manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import manytoone.EmployeeMTO;
import manytoone.ParkingMTO;

public class ManyToManyDao {
	public void doCrud() {
		EntityManagerFactory emf=null;
		EntityManager em=null;
		try {
			//jpa logic to perform insert operation
			emf = Persistence.createEntityManagerFactory("day2");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			List<Course> clist = new ArrayList<>();
			 Course c1 = new Course();
			 c1.setCourseId(1);
			 c1.setCourseName("course1");
			 Course c2 = new Course();
			 c2.setCourseId(2);
			 c2.setCourseName("course2");
			 clist.add(c1);
			 clist.add(c2);
			Student s = new Student();
			s.setStudentId(101);
			s.setStudentName("ram");
			s.setCourses(clist);
			em.persist(s);
			em.getTransaction().commit();
			

		}catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();

			}
		}
	

	}

}
